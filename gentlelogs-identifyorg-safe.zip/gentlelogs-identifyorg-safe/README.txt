GENTLELOGS — IDENTIFYORG PREPARATION FILES

This is a safe, non-live Cloudflare Pages Functions scaffold.
It does NOT create charges, receive/verify provider webhooks, or credit wallets.

Folder structure to copy into the root of the GentleLogs Cloudflare Pages project:

functions/
  api/
    create-payment.js
    identifyorg-webhook.js
    payment-status.js

The two updated frontend files are supplied separately:
- fund-identifyorg-prep.html
- payment-identifyorg-prep.html

Important:
1. Keep firebase.js and the rest of the existing site files in place.
2. Cloudflare Pages detects the functions/ directory at the project root.
3. These stubs intentionally return HTTP 503 until a properly reviewed integration exists.
4. Never put IdentifyOrg API keys or Firebase service-account credentials in browser code,
   public HTML, Git, or a message/chat.
5. A successful redirect is not proof of payment. A future server implementation must
   authenticate the webhook according to IdentifyOrg's official specification, verify
   the payment server-side, check the amount/currency/customer/reference, and prevent
   duplicate credits.
6. Do not loosen Firestore rules to let customers edit wallet balances or mark funding
   requests as paid.

This preparation scaffold is not a live payment integration.
