/**
 * GentleLogs / Cloudflare Pages Function
 * SAFE PREPARATION STUB — no payment status is inferred from a redirect.
 * A future implementation must authenticate the customer, verify the
 * provider-side payment status, and enforce idempotency before any credit.
 */
export async function onRequestGet() {
  return new Response(JSON.stringify({
    code: 'PAYMENT_STATUS_NOT_CONFIGURED',
    message: 'Payment verification is not available yet.'
  }), {
    status: 503,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store'
    }
  });
}
