/**
 * GentleLogs / Cloudflare Pages Function
 * SAFE PREPARATION STUB — intentionally does not accept or process payments.
 * Do not connect a live provider webhook to this endpoint until an eligible
 * adult account owner has completed onboarding and the official webhook
 * authentication/signature specification has been reviewed.
 */
export async function onRequestPost() {
  return new Response(JSON.stringify({
    code: 'WEBHOOK_NOT_CONFIGURED',
    message: 'Payment notifications are not configured.'
  }), {
    status: 503,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store'
    }
  });
}
