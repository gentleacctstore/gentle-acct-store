/**
 * GentleLogs / Cloudflare Pages Function
 * SAFE PREPARATION STUB — does not create a real charge.
 * Live payment activation and real-money operations must be configured by
 * an eligible adult account owner after provider onboarding and review.
 */
export async function onRequestPost({ request }) {
  const contentType = request.headers.get('content-type') || '';
  if (!contentType.includes('application/json')) {
    return json({ message: 'Send a JSON request.' }, 415);
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return json({ message: 'Invalid JSON request.' }, 400);
  }

  const amount = Number(body?.amount);
  const methods = new Set(['transfer', 'card', 'ussd']);
  if (!Number.isSafeInteger(amount) || amount < 100 || amount > 5_000_000) {
    return json({ message: 'Amount must be between ₦100 and ₦5,000,000.' }, 400);
  }
  if (body?.currency !== 'NGN' || !methods.has(body?.paymentMethod)) {
    return json({ message: 'Unsupported currency or payment method.' }, 400);
  }

  // Deliberately disabled: no provider API call, no secret, no charge,
  // no funding request and no wallet credit in this preparation build.
  return json({
    code: 'PAYMENTS_NOT_CONFIGURED',
    message: 'Secure checkout is not activated yet. Please try again later.'
  }, 503);
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store'
    }
  });
}
